/*
* config.Db contient les parametres de connection à la base de données mongo db
*
*/

// Retrieve
var MongoClient = require('mongodb').MongoClient;

// Connect to the db
MongoClient.connect("ds137121.mlab.com:37121/heroku_6pwg8vg8", function(err, db) {
  if(!err) {
    console.log("We are connected");
  }
});